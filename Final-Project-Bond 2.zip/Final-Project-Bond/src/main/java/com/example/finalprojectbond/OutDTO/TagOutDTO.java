package com.example.finalprojectbond.OutDTO;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@AllArgsConstructor
@Setter
@Getter
public class TagOutDTO {
    private String tag;
}
